
# Scalable Web App (Demo)

This is a minimal full-stack boilerplate for the assignment:
- React frontend (minimal) in /frontend
- Node.js + Express backend in /backend
- MongoDB for persistence (Mongoose)
- JWT authentication, bcrypt password hashing
- Protected routes, tasks CRUD, search

See README-backend.md and README-frontend.md in each folder for run instructions.
