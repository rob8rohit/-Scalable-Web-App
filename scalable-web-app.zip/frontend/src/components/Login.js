import React, { useState } from 'react';
export default function Login({ onLogin, switchToSignup, api }){
  const [email,setEmail]=useState(''); const [password,setPassword]=useState(''); const [err,setErr]=useState('');
  const submit = async (e)=>{
    e.preventDefault(); setErr('');
    try{
      const res = await fetch(api + '/api/auth/login', { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({ email, password }) });
      const data = await res.json();
      if (!res.ok) return setErr(data.message || 'Login failed');
      onLogin(data.token);
    }catch(err){ setErr('Network error'); }
  };
  return (
    <form onSubmit={submit}>
      <h3>Login</h3>
      {err && <div style={{color:'red'}}>{err}</div>}
      <input value={email} onChange={e=>setEmail(e.target.value)} placeholder="Email" />
      <input value={password} onChange={e=>setPassword(e.target.value)} placeholder="Password" type="password" />
      <button className="btn btn-primary" type="submit">Login</button>
      <div style={{marginTop:12}}>Don't have account? <button type="button" onClick={switchToSignup} className="btn">Signup</button></div>
    </form>
  );
}
