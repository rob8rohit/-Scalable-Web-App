import React, { useEffect, useState } from 'react';

export default function Dashboard({ api, token, logout }){
  const [profile, setProfile] = useState(null);
  const [tasks, setTasks] = useState([]);
  const [title, setTitle] = useState('');
  const [q, setQ] = useState('');

  useEffect(()=>{ fetchProfile(); fetchTasks(); }, []);

  const authGet = (url) => fetch(api + url, { headers: { Authorization: 'Bearer ' + token } }).then(r=>r.json());

  async function fetchProfile(){
    const data = await authGet('/api/user/me');
    setProfile(data);
  }

  async function fetchTasks(){
    const data = await authGet('/api/tasks?q=' + encodeURIComponent(q));
    setTasks(data || []);
  }

  async function addTask(e){
    e.preventDefault();
    await fetch(api + '/api/tasks', { method:'POST', headers:{'Content-Type':'application/json','Authorization':'Bearer ' + token}, body: JSON.stringify({ title }) });
    setTitle(''); fetchTasks();
  }

  async function toggleComplete(id, completed){
    await fetch(api + '/api/tasks/' + id, { method:'PUT', headers:{'Content-Type':'application/json','Authorization':'Bearer ' + token}, body: JSON.stringify({ completed: !completed }) });
    fetchTasks();
  }

  async function del(id){
    await fetch(api + '/api/tasks/' + id, { method:'DELETE', headers:{ Authorization:'Bearer ' + token } });
    fetchTasks();
  }

  return (
    <div>
      <div style={{display:'flex', justifyContent:'space-between', alignItems:'center'}}>
        <div><strong>Welcome,</strong> {profile ? profile.name : '...'}</div>
        <div><button className="btn" onClick={logout}>Logout</button></div>
      </div>

      <section style={{marginTop:16}}>
        <h4>Tasks</h4>
        <form onSubmit={addTask}>
          <input value={title} onChange={e=>setTitle(e.target.value)} placeholder="New task title" required />
          <button className="btn btn-primary" type="submit">Add</button>
        </form>

        <div style={{marginTop:12}}>
          <input placeholder="Search" value={q} onChange={e=>setQ(e.target.value)} />
          <button className="btn" onClick={fetchTasks}>Search</button>
        </div>

        <ul style={{marginTop:12}}>
          {tasks.map(t=>(
            <li key={t._id} style={{padding:8, borderBottom: '1px solid #eee'}}>
              <input type="checkbox" checked={t.completed} onChange={()=>toggleComplete(t._id, t.completed)} />
              <strong style={{marginLeft:8}}>{t.title}</strong>
              <button style={{marginLeft:12}} className="btn" onClick={()=>del(t._id)}>Delete</button>
            </li>
          ))}
        </ul>
      </section>
    </div>
  );
}
