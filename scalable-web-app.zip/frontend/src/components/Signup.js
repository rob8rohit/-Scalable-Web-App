import React, { useState } from 'react';
export default function Signup({ onSignup, switchToLogin, api }){
  const [name,setName]=useState(''); const [email,setEmail]=useState(''); const [password,setPassword]=useState(''); const [err,setErr]=useState('');
  const submit = async (e)=>{
    e.preventDefault(); setErr('');
    try{
      const res = await fetch(api + '/api/auth/signup', { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({ name, email, password }) });
      const data = await res.json();
      if (!res.ok) return setErr(data.message || 'Signup failed');
      onSignup(data.token);
    }catch(err){ setErr('Network error'); }
  };
  return (
    <form onSubmit={submit}>
      <h3>Signup</h3>
      {err && <div style={{color:'red'}}>{err}</div>}
      <input value={name} onChange={e=>setName(e.target.value)} placeholder="Full name" />
      <input value={email} onChange={e=>setEmail(e.target.value)} placeholder="Email" />
      <input value={password} onChange={e=>setPassword(e.target.value)} placeholder="Password" type="password" />
      <button className="btn btn-primary" type="submit">Signup</button>
      <div style={{marginTop:12}}>Already have account? <button type="button" onClick={switchToLogin} className="btn">Login</button></div>
    </form>
  );
}
