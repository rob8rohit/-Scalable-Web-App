import React, { useEffect, useState } from 'react';
import Login from './components/Login';
import Signup from './components/Signup';
import Dashboard from './components/Dashboard';

const API = process.env.REACT_APP_API_URL || 'http://localhost:5000';

function App() {
  const [token, setToken] = useState(localStorage.getItem('token'));
  const [view, setView] = useState('login');

  useEffect(()=>{ if (token) setView('dashboard'); }, [token]);

  const logout = ()=> { localStorage.removeItem('token'); setToken(null); setView('login'); };

  return (
    <div className="container">
      <h2>Scalable Web App — Demo</h2>
      {!token && view === 'login' && <Login onLogin={(t)=>{ localStorage.setItem('token', t); setToken(t); }} switchToSignup={()=>setView('signup')} api={API} />}
      {!token && view === 'signup' && <Signup onSignup={(t)=>{ localStorage.setItem('token', t); setToken(t); }} switchToLogin={()=>setView('login')} api={API} />}
      {token && <Dashboard api={API} token={token} logout={logout} />}
    </div>
  );
}

export default App;
