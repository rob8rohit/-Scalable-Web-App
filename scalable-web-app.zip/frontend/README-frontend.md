Frontend (React)
----------------
- Install: `npm install`
- Run: `npm start`
- Notes: This is a minimal React app with example components for Login, Signup, and Dashboard that call the backend APIs.
- Set REACT_APP_API_URL in .env to point to the backend, e.g. http://localhost:5000
