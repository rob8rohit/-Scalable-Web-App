const express = require('express');
const router = express.Router();
const Task = require('../models/Task');

// Create task
router.post('/', async (req, res, next) => {
  try {
    const task = await Task.create({ ...req.body, user: req.userId });
    res.json(task);
  } catch (err) { next(err); }
});

// Read all (with simple search query ?q=)
router.get('/', async (req, res, next) => {
  try {
    const q = req.query.q || '';
    const tasks = await Task.find({ user: req.userId, title: { $regex: q, $options: 'i' } }).sort({ createdAt: -1 });
    res.json(tasks);
  } catch (err) { next(err); }
});

// Get single
router.get('/:id', async (req, res, next) => {
  try {
    const task = await Task.findOne({ _id: req.params.id, user: req.userId });
    if (!task) return res.status(404).json({ message: 'Not found' });
    res.json(task);
  } catch (err) { next(err); }
});

// Update
router.put('/:id', async (req, res, next) => {
  try {
    const task = await Task.findOneAndUpdate({ _id: req.params.id, user: req.userId }, req.body, { new: true });
    res.json(task);
  } catch (err) { next(err); }
});

// Delete
router.delete('/:id', async (req, res, next) => {
  try {
    await Task.findOneAndDelete({ _id: req.params.id, user: req.userId });
    res.json({ success: true });
  } catch (err) { next(err); }
});

module.exports = router;
