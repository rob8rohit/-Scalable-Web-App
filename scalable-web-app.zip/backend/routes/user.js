const express = require('express');
const router = express.Router();
const User = require('../models/User');

router.get('/me', async (req, res, next) => {
  try {
    const user = await User.findById(req.userId).select('-password');
    res.json(user);
  } catch (err) { next(err); }
});

router.put('/me', async (req, res, next) => {
  try {
    const { name } = req.body;
    const user = await User.findByIdAndUpdate(req.userId, { name }, { new: true }).select('-password');
    res.json(user);
  } catch (err) { next(err); }
});

module.exports = router;
